Release Notes
=============

.. toctree::
   :maxdepth: 1
   :glob:

   releases/1_1_5
   releases/1_1_4
   releases/1_1_3
   releases/1_1_2
   releases/1_1_1
   releases/1_0_2
   releases/1_0_1
   releases/1_0_0
   releases/0_9_16
   releases/0_9_15
   releases/0_9_14
   releases/0_9_12
   releases/0_9_11
   releases/0_9_10
   releases/0_9_9
   releases/0_9_8
   releases/0_9_7
   releases/0_9_6
   releases/0_9_5
   releases/0_9_4
   releases/0_9_3
   releases/0_9_2
