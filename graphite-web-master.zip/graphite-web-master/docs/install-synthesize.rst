Installing From Synthesize
==========================

`Synthesize <https://github.com/obfuscurity/synthesize/>`_ is a script dedicated to making Graphite easy to install. As of this writing, the default installation provides Graphite 0.9.15 for Ubuntu Linux 14.04 LTS with an experimental release candidate for tracking Graphite ``HEAD``. Users may run the installation script manually, or they can choose to use the provided Vagrantfile.

For detailed instructions, please refer to the official project documentation on the `Synthesize <https://github.com/obfuscurity/synthesize/>`_ website.
