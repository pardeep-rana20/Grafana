Who is using Graphite?
======================

Here are some organizations that use Graphite:

* `Brightcove <http://www.brightcove.com>`_ (see http://opensource.brightcove.com/project/Diamond/)
* `Canonical <http://www.canonical.com>`_
* `Datacratic <http://www.datacratic.com>`_
* `Douban <http://www.douban.com>`_
* `Dyn <http://dyn.com/>`_
* `Etsy <http://www.etsy.com/>`_ (see http://codeascraft.etsy.com/2010/12/08/track-every-release/)
* `GapLabs, a division of Gap Inc. <http://www.gapinc.com/content/gapinc/html/aboutus/ourbrands.html>`_
* `GitHub <https://github.com>`_
* `Google <http://google-opensource.blogspot.com/2010/09/get-ready-to-rocksteady.html>`_ (opensource Rocksteady project)
* `GOV.UK <https://www.gov.uk>`_
* `ImmobilienScout24 <http://www.immobilienscout24.de/>`_
* `InMobi <http://inmobi.com/>`_
* `Instagram <http://instagram.com/>`_
* `ITV <http://www.itv.com/>`_
* `Maaii <http://www.maaii.com>`_
* `Mackerel <https://mackerel.io>`_
* `Media Temple <http://mediatemple.net/>`_
* `Oracle <http://www.oracle.com/>`_
* `Orbitz <http://www.orbitz.com/>`_
* `Outbrain <http://outbrain.com/>`_ (see https://github.com/outbrain/gruffalo)
* `Pandora <http://www.pandora.com/>`_
* `Rubicon Project <http://www.rubiconproject.com/>`_
* `Sears Holdings <http://www.sears.com/>`_
* `SocialTwist <http://www.socialtwist.com>`_
* `Uber <http://uber.com/>`_
* `Vimeo <http://www.vimeo.com>`_
* `Wikimedia Foundation <http://gdash.wikimedia.org/>`_

And many more
