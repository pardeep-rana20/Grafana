def test(seriesList):
  """This is a test function"""
  return seriesList


test.group = 'Test'

SeriesFunctions = {
  'testFunc': test,
}
