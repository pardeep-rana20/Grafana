class NormalizeEmptyResultError(Exception):
  # throw error for normalize() when empty
  pass
