from django.contrib import admin
from graphite.dashboard.models import Dashboard

admin.site.register(Dashboard)
