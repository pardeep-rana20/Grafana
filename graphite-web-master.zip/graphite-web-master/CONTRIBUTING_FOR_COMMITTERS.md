First of all, Welcome, and Thank You!

I don't know about you, but I'm in it for all of the glory that Obfuscurity promised...

The team has grown some in the last year or so, so let's get some ground rules:

* Be polite to the community.
* We are part of the community.
* Don't commit directly to the public repo.  Please Fork and PR.
* Unless things are publicly broken and nobody else is around to validate, don't merge your own PR.
* If you're going to do something directly on the main repo, or something Meta (tags, releases, etc), other people should probably know about it. When in doubt, check with Obfuscurity or MLeinart.
* Be polite to the community.
